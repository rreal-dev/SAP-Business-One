﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TB1300
{
    public partial class GeneralObjects : Form
    {
        SAPbobsCOM.BusinessPartners oBP;
        public GeneralObjects()
        {
            InitializeComponent();
        }

        private void GeneralObjects_Load(object sender, EventArgs e)
        {
            
            SAPbobsCOM.Recordset oRecordSet;
            
            oBP = ((SAPbobsCOM.BusinessPartners)(Form1.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oBusinessPartners)));
            oRecordSet = ((SAPbobsCOM.Recordset)(Form1.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)));
            oRecordSet.DoQuery("SELECT * FROM OCRD WHERE CardType = 'C'");
            oBP.Browser.Recordset = oRecordSet;
            //MessageBox.Show(oBP.ToString());
            this.txtCardCode.Clear();
            //int ret = oBP.Add();
            oBP.Browser.MoveFirst();
            this.txtCardCode.Text = oBP.CardCode;
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            oBP.Browser.MoveNext();
            this.txtCardCode.Text = oBP.CardCode;
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            oBP.Browser.MoveLast();
            this.txtCardCode.Text = oBP.CardCode;
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            oBP.Browser.MovePrevious();
            this.txtCardCode.Text = oBP.CardCode;
        }

        private void btnFirst_Click(object sender, EventArgs e)
        {
            oBP.Browser.MoveFirst();
            this.txtCardCode.Text = oBP.CardCode;
        }
    }
}
