﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TB1300
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        
        private static SAPbouiCOM.Application SBO_Application;
        private static SAPbobsCOM.Company diCompany;

        [STAThread]
        static void Main()
        {
            ConnectToUI();
            SBO_Application.AppEvent += new SAPbouiCOM._IApplicationEvents_AppEventEventHandler(SBO_Application_AppEvent);
            Application.Run();
        }

        private static void ConnectToUI()
        {
            SAPbouiCOM.SboGuiApi SboGuiApi;
            string sConnectionString;

            SboGuiApi = new SAPbouiCOM.SboGuiApi();
            sConnectionString = System.Convert.ToString(Environment.GetCommandLineArgs().GetValue(1));

            SboGuiApi.Connect(sConnectionString);
            SBO_Application = SboGuiApi.GetApplication();

            SBO_Application.MessageBox("Connected to UI API", 1, "Continue", "Cancel");
            //ConnectwithSSO();
            ConnectwithSharedMemory();
        }
        private static void ConnectwithSSO()
        {
            diCompany = new SAPbobsCOM.Company();
            string cookie = diCompany.GetContextCookie();
            string connInfo = SBO_Application.Company.GetConnectionContext(cookie);

            int ret = diCompany.SetSboLoginContext(connInfo);
            if (ret != 0)
                SBO_Application.MessageBox("DI Connection failed!", 0, "Ok", "", "");
            else
                SBO_Application.MessageBox("Connected with SSO!", 0, "Ok", "", "");
        }
        private static void ConnectwithSharedMemory()
        {
            diCompany = (SAPbobsCOM.Company)Program.SBO_Application.Company.GetDICompany();
            SBO_Application.MessageBox("DI Connected To: " + Program.diCompany.CompanyName, 0, "Ok", "", "");
        }

        public static void SBO_Application_AppEvent(SAPbouiCOM.BoAppEventTypes EventType)
        {
            switch (EventType)
            {
                case SAPbouiCOM.BoAppEventTypes.aet_ShutDown:
                    //Exit Add-On
                    SBO_Application.MessageBox("My is addon disconnected." + Program.diCompany.CompanyName, 0, "Ok", "", "");
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(Program.diCompany);
                    Application.Exit();       
                    break;
                case SAPbouiCOM.BoAppEventTypes.aet_CompanyChanged:
                    break;
                case SAPbouiCOM.BoAppEventTypes.aet_FontChanged:
                    break;
                case SAPbouiCOM.BoAppEventTypes.aet_LanguageChanged:
                    break;
                case SAPbouiCOM.BoAppEventTypes.aet_ServerTerminition:
                    break;
                default:
                    break;
            }
        }

    }
}
