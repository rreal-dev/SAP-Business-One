﻿using System;
using System.Data.Services.Client;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Windows.Forms;

namespace TB1300
{
    public partial class Form1 : Form
    {
        public static MyServiceLayer.SAPB1.ServiceLayer slContext = null;
        private string CookieString;
        public MyServiceLayer.SAPB1.B1Session ServiceLayerSession = null;
        public ReceivingResponseEventArgs webResponse = null;
        public Form1()
        {
            InitializeComponent();
        }

        void SLSendingRequest(object sender, System.Data.Services.Client.SendingRequestEventArgs e)
        {
            HttpWebRequest request = (HttpWebRequest)e.Request;
            if (null != request)
            {
                request.Accept = "application/json;odata=minimalmetadata";
                request.KeepAlive = true;                               //keep alive
                request.ServicePoint.Expect100Continue = false;        //content
                request.AllowAutoRedirect = true;
                request.ContentType = "application/json;odata=minimalmetadata;charset=utf8";
                request.Timeout = 100000;    //100 seconds.
                if (!string.IsNullOrEmpty(CookieString))
                {
                    e.RequestHeaders.Add("Cookie", CookieString);
                }
            }
            else
            {
                throw new Exception("Failed to intercept the sending request");
            }
        }

        void SLReceivingResponse(object sender, ReceivingResponseEventArgs e)
        {
            if (null == e.ResponseMessage)
                return;

            string strMessage = e.ResponseMessage.GetHeader("Set-Cookie");

            if (!string.IsNullOrEmpty(strMessage))
            {
                CookieString = strMessage.Replace(',', ';');
            }
            webResponse = e;
        }
        private static bool RemoteSSLTLSCertificateValidate(object sender, X509Certificate cert, X509Chain chain, SslPolicyErrors ssl)
        {
            return true;
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            slContext = new MyServiceLayer.SAPB1.ServiceLayer(new Uri("https:/YourHANAServerAddress:50000/b1s/v1/"));
            slContext.Format.UseJson();
            
            slContext.SendingRequest += SLSendingRequest;
            slContext.ReceivingResponse += SLReceivingResponse;
            slContext.MergeOption = MergeOption.OverwriteChanges;
            ServicePointManager.ServerCertificateValidationCallback += RemoteSSLTLSCertificateValidate;

            try
            {
                Uri login = new Uri("/Login", UriKind.Relative);
                BodyOperationParameter[] body = new BodyOperationParameter[3];
                body[0] = new BodyOperationParameter("UserName", "manager");
                body[1] = new BodyOperationParameter("Password", "manager");
                body[2] = new BodyOperationParameter("CompanyDB", "SBODEMOSK");
                if (ServiceLayerSession == null)
                    ServiceLayerSession = (MyServiceLayer.SAPB1.B1Session)slContext.Execute<MyServiceLayer.SAPB1.B1Session>(login, "POST", true, body).SingleOrDefault();

                txtMain.AppendText("Session id = " + ServiceLayerSession.SessionId + System.Environment.NewLine);
            }
            catch (Exception ex)
            {
                txtMain.AppendText(ex + System.Environment.NewLine);
                return;
            }
        }

        private void btnDisconnect_Click(object sender, EventArgs e)
        {
            Uri logout = new Uri("/Logout", UriKind.Relative);
            if (ServiceLayerSession != null)
                ServiceLayerSession = slContext.Execute<MyServiceLayer.SAPB1.B1Session>(logout, "POST", true).SingleOrDefault();
            if (ServiceLayerSession == null)
                txtMain.AppendText("You had been disconnected." + System.Environment.NewLine);
        }

        private void btnUDT_Click(object sender, EventArgs e)
        {
            AddUserDefinedTable("TB1_MYTABLE2", "UDO Document", "bott_Document");
            AddUserDefinedTable("TB1_MYTABLE3", "UDO Document Row", "bott_DocumentLines");
        }

        private void AddUserDefinedTable(string TableName, string Description, string Type)
        {
            try
            {
                Uri httpAction = new Uri("/UserTablesMD", UriKind.Relative);
                BodyOperationParameter[] body = new BodyOperationParameter[3];
                body[0] = new BodyOperationParameter("TableName", TableName);
                body[1] = new BodyOperationParameter("TableDescription", Description);
                body[2] = new BodyOperationParameter("TableType", Type);
                MyServiceLayer.SAPB1.UserTablesMD UserDefinedTable = null;

                UserDefinedTable = (MyServiceLayer.SAPB1.UserTablesMD)slContext.Execute<MyServiceLayer.SAPB1.UserTablesMD>(httpAction, "POST", true, body).SingleOrDefault();

                if (webResponse.ResponseMessage.StatusCode == 201)
                    txtMain.AppendText("Table created, TableName = " + TableName + System.Environment.NewLine);
            }
            catch (Exception ex)
            {
                if (webResponse.ResponseMessage.StatusCode <= 199 || webResponse.ResponseMessage.StatusCode >= 300)
                {
                    txtMain.AppendText("StatusCode = " + webResponse.ResponseMessage.StatusCode + System.Environment.NewLine);
                    wsResponseError currentError = Newtonsoft.Json.JsonConvert.DeserializeObject<wsResponseError>(ex.InnerException.Message);
                    txtMain.AppendText("ErrorCode = " + currentError.error.code + System.Environment.NewLine);
                    txtMain.AppendText("ErrorMessage = " + currentError.error.message.value + System.Environment.NewLine);
                }
                else
                {
                    txtMain.AppendText(ex + System.Environment.NewLine);
                }
                webResponse = null;
                return;
            }
        }

        public class wsResponseError
        {
            public err error { get; set; }

            public class err
            {
                public string code { get; set; }
                public msg message { get; set; }
            }

            public class msg
            {
                public string lang { get; set; }
                public string value { get; set; }
            }
        }

        private void btnUDF_Click(object sender, EventArgs e)
        {
            AddUserDefinedField("udf1", "db_Alpha", 20, "field 01", "@TB1_MYTABLE2");
            AddUserDefinedField("udf2", "db_Alpha", 20, "field 02", "@TB1_MYTABLE3");
        }

        private void AddUserDefinedField(string Name, string Type, int Size, string Description, string TableName)
        {
            try
            {
                Uri httpAction = new Uri("/UserFieldsMD", UriKind.Relative);
                BodyOperationParameter[] body = new BodyOperationParameter[5];
                body[0] = new BodyOperationParameter("Name", Name);
                body[1] = new BodyOperationParameter("Type", Type);
                body[2] = new BodyOperationParameter("Size", Size);
                body[3] = new BodyOperationParameter("Description", Description);
                body[4] = new BodyOperationParameter("TableName", TableName);
                MyServiceLayer.SAPB1.UserFieldMD UserDefinedField = null;

                UserDefinedField = (MyServiceLayer.SAPB1.UserFieldMD)slContext.Execute<MyServiceLayer.SAPB1.UserFieldMD>(httpAction, "POST", true, body).SingleOrDefault();

                if (webResponse.ResponseMessage.StatusCode == 201)
                    txtMain.AppendText("Field created, FieldName = " + Name + System.Environment.NewLine);
            }
            catch (Exception ex)
            {
                if (webResponse.ResponseMessage.StatusCode <= 199 || webResponse.ResponseMessage.StatusCode >= 300)
                {
                    txtMain.AppendText("StatusCode = " + webResponse.ResponseMessage.StatusCode + System.Environment.NewLine);
                    wsResponseError currentError = Newtonsoft.Json.JsonConvert.DeserializeObject<wsResponseError>(ex.InnerException.Message);
                    txtMain.AppendText("ErrorCode = " + currentError.error.code + System.Environment.NewLine);
                    txtMain.AppendText("ErrorMessage = " + currentError.error.message.value + System.Environment.NewLine);
                }
                else
                {
                    txtMain.AppendText(ex + System.Environment.NewLine);
                }
                webResponse = null;
                return;
            }
        }

        private void btnUDK_Click(object sender, EventArgs e)
        {
            var httpWebRequest = WebRequest.Create("https://YourHANAServerAddress:50000/b1s/v1/UserKeysMD") as HttpWebRequest;

            try
            {
                httpWebRequest.Method = "POST";
                httpWebRequest.AllowAutoRedirect = false;
                httpWebRequest.Timeout = 30 * 1000;
                httpWebRequest.ServicePoint.Expect100Continue = false;
                httpWebRequest.CookieContainer = new CookieContainer();

                string[] cookieItems = CookieString.Split(';');
                foreach (var cookieItem in cookieItems)
                {
                    string[] parts = cookieItem.Split('=');
                    if (parts.Length == 2)
                    {
                        httpWebRequest.CookieContainer.Add(httpWebRequest.RequestUri, new Cookie(parts[0].Trim(), parts[1].Trim()));
                    }
                }

                using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
                {
                    string json = "{\"TableName\": \"@TB1_MYTABLE2\", \"KeyIndex\": 0, \"KeyName\": \"key1\", \"Unique\": \"tYES\", \"UserKeysMD_Elements\": [{\"ColumnAlias\": \"udf1\"}]}";

                    streamWriter.Write(json);
                    streamWriter.Flush();
                    streamWriter.Close();
                }

                var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse() as HttpWebResponse;
                string responseContent = null;
                if (httpResponse.StatusCode == HttpStatusCode.Created)
                    using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                    {
                        responseContent = streamReader.ReadToEnd();
                        var oResult = Newtonsoft.Json.JsonConvert.DeserializeObject<System.Collections.Generic.IDictionary<string, object>>(responseContent);
                        var keyName = oResult["KeyName"].ToString();
                        txtMain.AppendText("Key created, KeyName =  " + keyName + System.Environment.NewLine);
                    }
                else
                    txtMain.AppendText("Error: " + System.Environment.NewLine);

            }
            catch (Exception ex)
            {
                txtMain.AppendText(ex + System.Environment.NewLine);
                return;
            }
        }

        private void btnUDO_Click(object sender, EventArgs e)
        {
            try
            {
                var httpWebRequest = WebRequest.Create("https://YourHANAServerAddress:50000/b1s/v1/UserObjectsMD") as HttpWebRequest;
                httpWebRequest.Method = "POST";
                httpWebRequest.AllowAutoRedirect = false;
                httpWebRequest.Timeout = 30 * 1000;
                httpWebRequest.ServicePoint.Expect100Continue = false;
                httpWebRequest.CookieContainer = new CookieContainer();

                string[] cookieItems = CookieString.Split(';');
                foreach (var cookieItem in cookieItems)
                {
                    string[] parts = cookieItem.Split('=');
                    if (parts.Length == 2)
                    {
                        httpWebRequest.CookieContainer.Add(httpWebRequest.RequestUri, new Cookie(parts[0].Trim(), parts[1].Trim()));
                    }
                }

                using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
                {
                    string json = "{\"Code\": \"MyOrder\", \"Name\": \"My Orders\", \"TableName\": \"TB1_MYTABLE2\", \"ObjectType\": \"boud_Document\", " +
                        "\"CanDelete\": \"tYES\", \"CanFind\": \"tYES\", \"UseUniqueFormType\": \"tYES\", \"EnableEnhancedForm\": \"tYES\", \"RebuildEnhancedForm\": \"tYES\", " +
                        "\"UserObjectMD_ChildTables\": [{\"TableName\": \"TB1_MYTABLE3\", \"ObjectName\": \"MyOrderLines\"}], " +
                        "\"UserObjectMD_FindColumns\": [ " +
                        "{\"Code\": \"MYTABLE2\", \"ColumnNumber\": \"1\", \"ColumnAlias\": \"DocNum\", \"ColumnDescription\": \"DocNum\"}, " +
                        "{\"Code\": \"MYTABLE2\", \"ColumnNumber\": \"2\", \"ColumnAlias\": \"CreateDate\", \"ColumnDescription\": \"CreateDate\"}," +
                        "{\"Code\": \"MYTABLE2\", \"ColumnNumber\": \"3\", \"ColumnAlias\": \"UpdateDate\", \"ColumnDescription\": \"UpdateDate\"}, " +
                        "{\"Code\": \"MYTABLE2\", \"ColumnNumber\": \"4\", \"ColumnAlias\": \"U_udf1\", \"ColumnDescription\": \"U_udf1\"}]}";

                    streamWriter.Write(json);
                    streamWriter.Flush();
                    streamWriter.Close();
                }

                var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse() as HttpWebResponse;
                string responseContent = null;
                if (httpResponse.StatusCode == HttpStatusCode.Created)
                {
                    using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                    {
                        responseContent = streamReader.ReadToEnd();
                        var oResult = Newtonsoft.Json.JsonConvert.DeserializeObject<System.Collections.Generic.IDictionary<string, object>>(responseContent);
                        var entry = oResult["Code"].ToString();
                        txtMain.AppendText("UDO created, UDOCode = " + entry + System.Environment.NewLine);
                    }
                }
                else
                    txtMain.AppendText("Error: " + System.Environment.NewLine);
            }
            catch (Exception ex)
            {
                txtMain.AppendText(ex + System.Environment.NewLine);
                return;
            }
        }

        private void btnInsertUDOEntry_Click(object sender, EventArgs e)
        {
            var httpWebRequest = WebRequest.Create("https://YourHANAServerAddress:50000/b1s/v1/MyOrder") as HttpWebRequest;

            try
            {
                httpWebRequest.Method = "POST";
                httpWebRequest.AllowAutoRedirect = false;
                httpWebRequest.Timeout = 30 * 1000;
                httpWebRequest.ServicePoint.Expect100Continue = false;
                httpWebRequest.CookieContainer = new CookieContainer();

                string[] cookieItems = CookieString.Split(';');
                foreach (var cookieItem in cookieItems)
                {
                    string[] parts = cookieItem.Split('=');
                    if (parts.Length == 2)
                    {
                        httpWebRequest.CookieContainer.Add(httpWebRequest.RequestUri, new Cookie(parts[0].Trim(), parts[1].Trim()));
                    }
                }

                using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
                {
                    string currentTimeStamp = DateTime.Now.ToString("HH:mm:ss.fff");
                    string json = "{\"U_udf1\": \"" + currentTimeStamp + "\", \"MyOrderLinesCollection\":[{\"U_udf2\": \"my comment\"}]}";

                    streamWriter.Write(json);
                    streamWriter.Flush();
                    streamWriter.Close();
                }

                var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse() as HttpWebResponse;
                string responseContent = null;
                if (httpResponse.StatusCode == HttpStatusCode.Created)
                    using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                    {
                        responseContent = streamReader.ReadToEnd();
                        var oResult = Newtonsoft.Json.JsonConvert.DeserializeObject<System.Collections.Generic.IDictionary<string, object>>(responseContent);
                        var udoObject = oResult["Object"].ToString();
                        var udoDocNum = oResult["DocNum"].ToString();
                        txtMain.AppendText(udoObject + " created, DocNum =  " + udoDocNum + System.Environment.NewLine);
                    }
                else
                    txtMain.AppendText("Error: " + System.Environment.NewLine);

            }
            catch (Exception ex)
            {
                txtMain.AppendText(ex + System.Environment.NewLine);
                return;
            }
        }
    }
}
