﻿namespace TB1300
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnConnect = new System.Windows.Forms.Button();
            this.btnDisconnect = new System.Windows.Forms.Button();
            this.txtMain = new System.Windows.Forms.TextBox();
            this.btnUDT = new System.Windows.Forms.Button();
            this.btnUDF = new System.Windows.Forms.Button();
            this.btnUDK = new System.Windows.Forms.Button();
            this.btnUDO = new System.Windows.Forms.Button();
            this.btnInsertUDOEntry = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnConnect
            // 
            this.btnConnect.Location = new System.Drawing.Point(9, 10);
            this.btnConnect.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(102, 27);
            this.btnConnect.TabIndex = 0;
            this.btnConnect.Text = "Connect";
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // btnDisconnect
            // 
            this.btnDisconnect.Location = new System.Drawing.Point(386, 10);
            this.btnDisconnect.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnDisconnect.Name = "btnDisconnect";
            this.btnDisconnect.Size = new System.Drawing.Size(102, 27);
            this.btnDisconnect.TabIndex = 1;
            this.btnDisconnect.Text = "Disconnect";
            this.btnDisconnect.UseVisualStyleBackColor = true;
            this.btnDisconnect.Click += new System.EventHandler(this.btnDisconnect_Click);
            // 
            // txtMain
            // 
            this.txtMain.Location = new System.Drawing.Point(9, 51);
            this.txtMain.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtMain.Multiline = true;
            this.txtMain.Name = "txtMain";
            this.txtMain.Size = new System.Drawing.Size(479, 218);
            this.txtMain.TabIndex = 2;
            // 
            // btnUDT
            // 
            this.btnUDT.Location = new System.Drawing.Point(115, 10);
            this.btnUDT.Margin = new System.Windows.Forms.Padding(2);
            this.btnUDT.Name = "btnUDT";
            this.btnUDT.Size = new System.Drawing.Size(38, 27);
            this.btnUDT.TabIndex = 4;
            this.btnUDT.Text = "UDT";
            this.btnUDT.UseVisualStyleBackColor = true;
            this.btnUDT.Click += new System.EventHandler(this.btnUDT_Click);
            // 
            // btnUDF
            // 
            this.btnUDF.Location = new System.Drawing.Point(157, 10);
            this.btnUDF.Margin = new System.Windows.Forms.Padding(2);
            this.btnUDF.Name = "btnUDF";
            this.btnUDF.Size = new System.Drawing.Size(38, 27);
            this.btnUDF.TabIndex = 5;
            this.btnUDF.Text = "UDF";
            this.btnUDF.UseVisualStyleBackColor = true;
            this.btnUDF.Click += new System.EventHandler(this.btnUDF_Click);
            // 
            // btnUDK
            // 
            this.btnUDK.Location = new System.Drawing.Point(199, 10);
            this.btnUDK.Margin = new System.Windows.Forms.Padding(2);
            this.btnUDK.Name = "btnUDK";
            this.btnUDK.Size = new System.Drawing.Size(38, 27);
            this.btnUDK.TabIndex = 8;
            this.btnUDK.Text = "UDK";
            this.btnUDK.UseVisualStyleBackColor = true;
            this.btnUDK.Click += new System.EventHandler(this.btnUDK_Click);
            // 
            // btnUDO
            // 
            this.btnUDO.Location = new System.Drawing.Point(241, 10);
            this.btnUDO.Margin = new System.Windows.Forms.Padding(2);
            this.btnUDO.Name = "btnUDO";
            this.btnUDO.Size = new System.Drawing.Size(39, 27);
            this.btnUDO.TabIndex = 9;
            this.btnUDO.Text = "UDO";
            this.btnUDO.UseVisualStyleBackColor = true;
            this.btnUDO.Click += new System.EventHandler(this.btnUDO_Click);
            // 
            // btnInsertUDOEntry
            // 
            this.btnInsertUDOEntry.Location = new System.Drawing.Point(284, 10);
            this.btnInsertUDOEntry.Margin = new System.Windows.Forms.Padding(2);
            this.btnInsertUDOEntry.Name = "btnInsertUDOEntry";
            this.btnInsertUDOEntry.Size = new System.Drawing.Size(93, 27);
            this.btnInsertUDOEntry.TabIndex = 10;
            this.btnInsertUDOEntry.Text = "insert UDO entry";
            this.btnInsertUDOEntry.UseVisualStyleBackColor = true;
            this.btnInsertUDOEntry.Click += new System.EventHandler(this.btnInsertUDOEntry_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(496, 279);
            this.Controls.Add(this.btnInsertUDOEntry);
            this.Controls.Add(this.btnUDO);
            this.Controls.Add(this.btnUDK);
            this.Controls.Add(this.btnUDF);
            this.Controls.Add(this.btnUDT);
            this.Controls.Add(this.txtMain);
            this.Controls.Add(this.btnDisconnect);
            this.Controls.Add(this.btnConnect);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Form1";
            this.Text = "17_SL_Metadata";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.Button btnDisconnect;
        private System.Windows.Forms.TextBox txtMain;
        private System.Windows.Forms.Button btnUDT;
        private System.Windows.Forms.Button btnUDF;
        private System.Windows.Forms.Button btnUDK;
        private System.Windows.Forms.Button btnUDO;
        private System.Windows.Forms.Button btnInsertUDOEntry;
    }
}

