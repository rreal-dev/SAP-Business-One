﻿using System;
using System.Data.Services.Client;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Windows.Forms;

namespace TB1300
{
    public partial class Form1 : Form
    {
        public static MyServiceLayer.SAPB1.ServiceLayer slContext = null;
        private string CookieString;
        public MyServiceLayer.SAPB1.B1Session ServiceLayerSession = null;
        public Form1()
        {
            InitializeComponent();
        }

        void SLSendingRequest(object sender, System.Data.Services.Client.SendingRequestEventArgs e)
        {
            HttpWebRequest request = (HttpWebRequest)e.Request;
            if (null != request)
            {
                request.Accept = "application/json;odata=minimalmetadata";
                request.KeepAlive = true;                               //keep alive
                request.ServicePoint.Expect100Continue = false;        //content
                request.AllowAutoRedirect = true;
                request.ContentType = "application/json;odata=minimalmetadata;charset=utf8";
                request.Timeout = 100000;    //100 seconds.
                if (!string.IsNullOrEmpty(CookieString))
                {
                    e.RequestHeaders.Add("Cookie", CookieString);
                }
            }
            else
            {
                throw new Exception("Failed to intercept the sending request");
            }
        }

        void SLReceivingResponse(object sender, ReceivingResponseEventArgs e)
        {
            if (null == e.ResponseMessage)
                return;

            string strMessage = e.ResponseMessage.GetHeader("Set-Cookie");

            if (!string.IsNullOrEmpty(strMessage))
            {
                CookieString = strMessage.Replace(',', ';');
            }
        }
        private static bool RemoteSSLTLSCertificateValidate(object sender, X509Certificate cert, X509Chain chain, SslPolicyErrors ssl)
        {
            return true;
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            slContext = new MyServiceLayer.SAPB1.ServiceLayer(new Uri("https://YourHanaServerAddress:50000/b1s/v1/"));
            slContext.Format.UseJson();
            
            slContext.SendingRequest += SLSendingRequest;
            slContext.ReceivingResponse += SLReceivingResponse;
            slContext.MergeOption = MergeOption.OverwriteChanges;
            ServicePointManager.ServerCertificateValidationCallback += RemoteSSLTLSCertificateValidate;

            try
            {
                Uri login = new Uri("/Login", UriKind.Relative);
                BodyOperationParameter[] body = new BodyOperationParameter[3];
                body[0] = new BodyOperationParameter("UserName", "manager");
                body[1] = new BodyOperationParameter("Password", "manager");
                body[2] = new BodyOperationParameter("CompanyDB", "SBODEMOUS");
                if (ServiceLayerSession == null)
                    ServiceLayerSession = (MyServiceLayer.SAPB1.B1Session)slContext.Execute<MyServiceLayer.SAPB1.B1Session>(login, "POST", true, body).SingleOrDefault();

                txtMain.AppendText("Session id = " + ServiceLayerSession.SessionId + System.Environment.NewLine);
            }
            catch (Exception ex)
            {
                txtMain.AppendText(ex + System.Environment.NewLine);
                return;
            }
        }

        private void btnDisconnect_Click(object sender, EventArgs e)
        {
            Uri logout = new Uri("/Logout", UriKind.Relative);
            if (ServiceLayerSession != null)
                ServiceLayerSession = slContext.Execute<MyServiceLayer.SAPB1.B1Session>(logout, "POST", true).SingleOrDefault();
            if (ServiceLayerSession == null)
                txtMain.AppendText("You had been disconnected." + System.Environment.NewLine);
        }
    }
}
