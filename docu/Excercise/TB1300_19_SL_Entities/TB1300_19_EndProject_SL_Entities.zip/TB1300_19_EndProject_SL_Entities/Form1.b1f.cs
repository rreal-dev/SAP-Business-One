﻿using System;
using System.Collections.Generic;
using System.Xml;
using SAPbouiCOM.Framework;
using System.Security.Cryptography.X509Certificates;
using System.Net.Security;
using System.Net;
using System.IO;
using Newtonsoft.Json;

namespace TB1300
{
    [FormAttribute("TB1300.Form1", "Form1.b1f")]
    class Form1 : UserFormBase
    {
        private SAPbouiCOM.ComboBox cbCardType;
        private SAPbouiCOM.Button btnAddBP;
        private SAPbouiCOM.StaticText StaticText2;
        private SAPbouiCOM.EditText txCardCode;
        private SAPbouiCOM.EditText txCardName;
        private SAPbouiCOM.StaticText StaticText3;
        private SAPbouiCOM.StaticText StaticText4;
        private SAPbouiCOM.Button btnGetBP;
        private SAPbouiCOM.Grid grResult;
        public Form1()
        {
        }

        /// <summary>
        /// Initialize components. Called by framework after form created.
        /// </summary>
        public override void OnInitializeComponent()
        {
            this.btnAddBP = ((SAPbouiCOM.Button)(this.GetItem("btnAddBP").Specific));
            this.btnAddBP.ClickBefore += new SAPbouiCOM._IButtonEvents_ClickBeforeEventHandler(this.btnAddBP_ClickBefore);
            //  this.btnAddBP.ClickBefore += new SAPbouiCOM._IButtonEvents_ClickBeforeEventHandler(this.btnAddBP_ClickBefore);
            this.btnGetBP = ((SAPbouiCOM.Button)(this.GetItem("btnGetBP").Specific));
            this.btnGetBP.ClickBefore += new SAPbouiCOM._IButtonEvents_ClickBeforeEventHandler(this.btnGetBP_ClickBefore);
            //  this.btnGetBP.ClickBefore += new SAPbouiCOM._IButtonEvents_ClickBeforeEventHandler(this.btnGetBP_ClickBefore);
            this.grResult = ((SAPbouiCOM.Grid)(this.GetItem("grResult").Specific));
            this.cbCardType = ((SAPbouiCOM.ComboBox)(this.GetItem("cbCardType").Specific));
            this.StaticText2 = ((SAPbouiCOM.StaticText)(this.GetItem("Item_9").Specific));
            this.txCardCode = ((SAPbouiCOM.EditText)(this.GetItem("txCardCode").Specific));
            this.txCardName = ((SAPbouiCOM.EditText)(this.GetItem("txCardName").Specific));
            this.StaticText3 = ((SAPbouiCOM.StaticText)(this.GetItem("Item_7").Specific));
            this.StaticText4 = ((SAPbouiCOM.StaticText)(this.GetItem("Item_8").Specific));
            this.OnCustomInitialize();

        }

        /// <summary>
        /// Initialize form event. Called by framework before form creation.
        /// </summary>
        public override void OnInitializeFormEvents()
        {

        }

        private void OnCustomInitialize()
        {
            cbCardType.ValidValues.Add("C", "Customer");
            cbCardType.ValidValues.Add("S", "Supplier");
            cbCardType.ValidValues.Add("L", "Lead");
        }

        private static bool RemoteSSLTLSCertificateValidate(object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors errors)
        {
            return true;
        }

        private void btnAddBP_ClickBefore(object sboObject, SAPbouiCOM.SBOItemEventArg pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;

            try
            {
                var httpWebRequest = WebRequest.Create(Program.serviceLayerAddress + "/BusinessPartners") as HttpWebRequest;
                httpWebRequest.Method = "POST";
                httpWebRequest.AllowAutoRedirect = false;
                httpWebRequest.Timeout = 30 * 1000;
                httpWebRequest.ServicePoint.Expect100Continue = false;
                httpWebRequest.CookieContainer = new CookieContainer();
                ServicePointManager.ServerCertificateValidationCallback += RemoteSSLTLSCertificateValidate;

                string[] cookieItems = Program.sConnectionContext.Split(';');
                foreach (var cookieItem in cookieItems)
                {
                    string[] parts = cookieItem.Split('=');
                    if (parts.Length == 2)
                    {
                        httpWebRequest.CookieContainer.Add(httpWebRequest.RequestUri, new Cookie(parts[0].Trim(), parts[1].Trim()));
                    }
                }

                using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
                {
                    string json = "{\"CardCode\":\"" + txCardCode.Value + "\"," +
                                  "\"CardName\":\"" + txCardName.Value + "\"," +
                                  "\"CardType\":\"" + cbCardType.Value + "\"}";

                    streamWriter.Write(json);
                    streamWriter.Flush();
                    streamWriter.Close();
                }


                var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse() as HttpWebResponse;
                if (httpResponse.StatusCode != HttpStatusCode.Created)
                    Application.SBO_Application.MessageBox(httpResponse.StatusDescription, 1, "Ok");

                string responseContent = null;
                using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                    responseContent = streamReader.ReadToEnd();

                Application.SBO_Application.MessageBox(responseContent, 1, "Ok");
            }

            catch (Exception ex)
            {
                Application.SBO_Application.MessageBox(ex.ToString(), 1, "Ok");
            }
        }

        private void btnGetBP_ClickBefore(object sboObject, SAPbouiCOM.SBOItemEventArg pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;

            try
            {
                var httpWebRequest = WebRequest.Create(Program.serviceLayerAddress + "/BusinessPartners") as HttpWebRequest;
                httpWebRequest.Method = "GET";
                httpWebRequest.AllowAutoRedirect = false;
                httpWebRequest.Timeout = 30 * 1000;
                httpWebRequest.ServicePoint.Expect100Continue = false;
                httpWebRequest.CookieContainer = new CookieContainer();
                httpWebRequest.Headers.Add("B1S-PageSize", "0");
                ServicePointManager.ServerCertificateValidationCallback += RemoteSSLTLSCertificateValidate;

                string[] cookieItems = Program.sConnectionContext.Split(';');
                foreach (var cookieItem in cookieItems)
                {
                    string[] parts = cookieItem.Split('=');
                    if (parts.Length == 2)
                    {
                        httpWebRequest.CookieContainer.Add(httpWebRequest.RequestUri, new Cookie(parts[0].Trim(), parts[1].Trim()));
                    }
                }

                var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse() as HttpWebResponse;

                if (httpResponse.StatusCode != HttpStatusCode.OK)
                {
                    Application.SBO_Application.MessageBox(httpResponse.StatusDescription, 1, "Ok");
                }

                string responseContent = null;

                using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                {
                    responseContent = streamReader.ReadToEnd();
                    var oResult = JsonConvert.DeserializeObject<IDictionary<string, object>>(responseContent);

                    List<MyServiceLayer.SAPB1.BusinessPartner> l_B1BusinessPartners;
                    l_B1BusinessPartners = JsonConvert.DeserializeObject<List<MyServiceLayer.SAPB1.BusinessPartner>>(oResult["value"].ToString());

                    SAPbouiCOM.Form oForm = Application.SBO_Application.Forms.GetForm("TB1300.Form1", 0);
                    oForm.Freeze(true);
                    SAPbouiCOM.DataTable oDataTable;

                    if (grResult.Columns.Count == 0)
                        oDataTable = oForm.DataSources.DataTables.Add("myBPsDT");
                    else
                        oDataTable = oForm.DataSources.DataTables.Item("myBPsDT");


                    oDataTable.Clear();
                    oDataTable.Columns.Add("CardCode", SAPbouiCOM.BoFieldsType.ft_AlphaNumeric);
                    oDataTable.Columns.Add("CardName", SAPbouiCOM.BoFieldsType.ft_AlphaNumeric);
                    oDataTable.Columns.Add("CardType", SAPbouiCOM.BoFieldsType.ft_AlphaNumeric);

                    for (int i = 0; i <= l_B1BusinessPartners.Count - 1; i++)
                    {
                        oDataTable.Rows.Add();
                        oDataTable.SetValue(0, i, l_B1BusinessPartners[i].CardCode);
                        oDataTable.SetValue(1, i, l_B1BusinessPartners[i].CardName);
                        oDataTable.SetValue(2, i, l_B1BusinessPartners[i].CardType);
                    }

                    grResult.DataTable = oForm.DataSources.DataTables.Item("myBPsDT");
                    grResult.Columns.Item("CardCode").Type = SAPbouiCOM.BoGridColumnType.gct_EditText;
                    SAPbouiCOM.EditTextColumn oEdit = (SAPbouiCOM.EditTextColumn)grResult.Columns.Item("CardCode");
                    oEdit.LinkedObjectType = "2";

                    oForm.Freeze(false);
                }
            }
            catch (Exception ex)
            {
                Application.SBO_Application.MessageBox(ex.ToString(), 1, "Ok");
            }
        }
    }
}